﻿using System.Text.RegularExpressions;

class Program
{
    // main function that takes user input from command line and prints the output
    static void Main(string[] args)
    {
        Console.WriteLine("Please enter a sentence:");
        string input = Console.ReadLine();

        if (string.IsNullOrEmpty(input))
        {
            Console.WriteLine("No input provided!");
            return;
        }

        string output = TransformSentence(input);
        Console.WriteLine("Transformed Sentence: " + output);
    }

    // function to transform each word in the sentence as specified
    public static string TransformSentence(string sentence)
    {
        // regex to identify words and non-letters
        Regex wordRegex = new Regex(@"\w+|\W+");

        return string.Concat(wordRegex.Matches(sentence).Select(match =>
        {
            if (Regex.IsMatch(match.Value, @"\w+"))
            {
                return TransformedWord(match.Value);
            }
            else
            {
                // Return non-word characters as is
                return match.Value;
            }
        }));
    }

    // helper function to transform a word based on the unique character count rules
    private static string TransformedWord(string word)
    {
        if (word.Length > 1)
        {
            int distinctCharCount = word.Substring(1, word.Length - 2).Distinct().Count();
            return $"{word.First()}{distinctCharCount}{word.Last()}";
        }
        // return the word as is if it's a single character
        return word; 
    }
}
